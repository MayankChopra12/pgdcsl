

<?php
$x = 11;  
$y = 6;

echo $x + $y ,"\n";
echo $y * $y,"\n";
echo $x / $y,"\n";
echo $y - $y,"\n";
echo $x ^ $y,"\n";
echo $x ^ $y,"\n";
echo $x ^ $y,"\n";
?>  

