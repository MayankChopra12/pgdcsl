
    
if ("5" < "2323") {
  echo "true";
}
?>

<?php 
$d =date("D");
if (1==1)
echo "have a nice weekend";
else
echo "have a nice day!";
?>




